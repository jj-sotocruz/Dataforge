import re,os,glob
from PIL import Image,ImageDraw,ImageFont
R='/mnt/user-data/outputs/dataforge_html/'
rd=lambda p:open(R+p,encoding='utf8').read()
def wr(p,s): open(R+p,'w',encoding='utf8').write(s)
# ---------- imagen "en construcción" (en español)
S=2; W,H=800*S,660*S; im=Image.new('RGBA',(W,H),(255,255,255,0)); d=ImageDraw.Draw(im)
NAVY=(12,32,96);OR=(255,157,24);GR=(96,112,150);FB=lambda s:ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Carlito-Bold.ttf',s)
d.ellipse([250,330,1250,1330],fill=(214,229,250,255))
# grúa
for x in (1230,1330): d.line([(x,200),(x,1250)],fill=GR,width=14)
for y in range(200,1250,90): d.line([(1230,y),(1330,y+90)],fill=GR,width=8); d.line([(1330,y),(1230,y+90)],fill=GR,width=8)
d.rectangle([1190,1250,1370,1300],fill=NAVY)
d.line([(520,200),(1500,200)],fill=GR,width=14); d.line([(620,285),(1330,285)],fill=GR,width=10)
for x in range(620,1330,80): d.line([(x,285),(x+40,200)],fill=GR,width=7); d.line([(x+40,200),(x+80,285)],fill=GR,width=7)
d.line([(1280,200),(1280,80)],fill=GR,width=12); d.line([(1280,80),(520,200)],fill=GR,width=6); d.line([(1280,80),(1500,200)],fill=GR,width=6)
d.rectangle([1380,210,1500,340],fill=NAVY); d.rectangle([1335,225,1440,330],fill=(70,85,130)); d.rectangle([1352,242,1420,300],fill=(200,225,250))
# cable y gancho
d.line([(640,285),(640,520)],fill=NAVY,width=8); d.ellipse([618,500,662,544],outline=NAVY,width=8)
d.line([(640,544),(470,720)],fill=NAVY,width=6); d.line([(640,544),(850,720)],fill=NAVY,width=6)
# monitor
d.rounded_rectangle([260,640,1060,1100],34,fill=(222,228,245)); d.rectangle([290,670,1030,1000],fill=(255,255,255))
d.polygon([(610,1100),(710,1100),(740,1190),(580,1190)],fill=(190,200,225)); d.rounded_rectangle([500,1185,820,1215],14,fill=(170,182,215))
d.polygon([(380,1235),(1120,1235),(1210,1315),(290,1315)],fill=(205,214,238))
for i in range(1,4): d.line([(380-i*30,1235+i*20),(1120+i*30,1235+i*20)],fill=(255,255,255),width=4)
# cartel
d.rounded_rectangle([420,720,900,950],22,fill=OR,outline=NAVY,width=9)
t='EN CONSTRUCCIÓN'; f=FB(52); w=d.textlength(t,font=f); d.text((660-w/2,745),t,font=f,fill=NAVY)
d.polygon([(660,830),(722,925),(598,925)],fill=(255,255,255),outline=NAVY); d.line([(660,830),(722,925),(598,925),(660,830)],fill=NAVY,width=8,joint='curve')
f2=FB(60); d.text((660-d.textlength('!',font=f2)/2,858),'!',font=f2,fill=NAVY)
os.makedirs(R+'assets/Servicios',exist_ok=True)
im.resize((800,660),Image.LANCZOS).save(R+'assets/Servicios/construccion.webp','WEBP',quality=88,method=6)
# ---------- páginas de servicio (modelo "en construcción")
D={'dashboards-bi':'Conectamos tus fuentes de datos (ERP, CRM, hojas de Excel y APIs) y diseñamos tableros en Power BI, Looker o Metabase con los indicadores que tu equipo necesita para decidir. Entregamos el primer dashboard en 2 a 4 semanas y capacitamos a tu equipo para que lo use desde el primer día.',
 'analitica-descriptiva':'Reemplazamos los reportes manuales por informes automáticos, seguimiento de KPIs casi en tiempo real y alertas tempranas cuando una métrica se desvía de lo esperado. En 2 a 3 semanas tu empresa pasa a contar con información confiable y actualizada para entender qué está pasando en el negocio.',
 'machine-learning':'Construimos modelos predictivos con tus propios datos: predicción de demanda, abandono de clientes, scoring de crédito, mantenimiento predictivo y precios dinámicos. Validamos cada modelo antes de usarlo y lo entregamos en 4 a 8 semanas, con una explicación clara de cómo funciona y qué resultados esperar.',
 'mlops':'Llevamos tus modelos de Machine Learning a producción y los mantenemos funcionando: automatizamos los flujos de datos, desplegamos los modelos, monitoreamos su desempeño de forma continua y los reentrenamos cuando es necesario. Implementación en 3 a 6 semanas, para que tus modelos sigan siendo confiables con el tiempo.',
 'data-strategy':'Revisamos cómo se generan, almacenan y usan los datos en tu empresa, definimos la arquitectura de información y establecemos reglas de calidad, seguridad y cumplimiento normativo. En 2 a 4 semanas recibes un diagnóstico y una hoja de ruta clara para ordenar tus datos y aprovecharlos mejor.'}
for slug,desc in D.items():
    p=f'servicios/{slug}.html'; s=rd(p); name=re.search(r'<h1 id="servicio-title">(.*?)</h1>',s).group(1); plain=re.search(r'<!-- (.*?) -->',s).group(1)
    main=f'''<main id="contenido">
      <!-- {plain} -->
      <section id="servicio" aria-labelledby="servicio-title">
        <p>Servicios</p>
        <h1 id="servicio-title">{name}</h1>
        <h2>Esta página está en construcción</h2>
        <p>{desc}</p>
        <p>Estamos preparando el detalle completo de este servicio. Mientras tanto, puedes volver a la página de servicios.</p>
        <form action="servicios.html#servicios" method="get">
          <button type="submit">Volver a servicios</button>
        </form>
        <p><img src="../assets/Servicios/construccion.webp" alt="Ilustración de una grúa y un monitor con el cartel «En construcción»" width="400" height="330" loading="lazy" decoding="async"></p>
      </section>
    </main>'''
    wr(p,re.sub(r'<main id="contenido">.*?</main>',lambda m:main,s,flags=re.S))
# ---------- casos: sector como párrafo (sin negrita ni tamaño de título)
c=rd('casos_exito/casos_exito.html')
c,n=re.subn(r'<h2 id="(caso-[a-z]+)">([^<]+)</h2>\s*<h3>([^<]+)</h3>',lambda m:f'<p>{m.group(2)}</p>\n          <h2 id="{m.group(1)}">{m.group(3)}</h2>',c); assert n==3; wr('casos_exito/casos_exito.html',c)
# ---------- blog: quitar "Última actualización" y la 4.ª publicación
b=rd('blog/blog.html')
b,n1=re.subn(r'\s*<p>Última actualización:.*?</p>','',b); b,n2=re.subn(r'\s*<article>\s*<img src="../assets/Blog/card4\.webp".*?</article>','',b,flags=re.S); assert n1==1 and n2==1
wr('blog/blog.html',b)
if os.path.exists(R+'assets/Blog/card4.webp'): os.remove(R+'assets/Blog/card4.webp')
# ---------- portal: "Olvidé mi contraseña" vuelve a la caja de correo
p=rd('portal.html'); old='<a href="contacto.html#contacto">Olvidé mi contraseña</a>'; assert old in p
wr('portal.html',p.replace(old,'<a href="#portal-email">Olvidé mi contraseña</a>')); assert 'id="portal-email"' in rd('portal.html')
print('ok')
