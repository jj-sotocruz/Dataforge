import re,os
U='/mnt/user-data/uploads/'; O='/mnt/user-data/outputs/dataforge/'
loc={'home':'home','contacto':'home','portal':'home','servicios':'servicios','casos_exito':'casos_exito','nosotros':'nosotros','clientes':'clientes','blog':'blog'}
def rep(x,a,b,n=1,rx=False):
    c=len(re.findall(a,x,flags=re.S)) if rx else x.count(a)
    assert c>=1,('no encontrado',a[:60])
    return re.sub(a,b,x,count=n,flags=re.S) if rx else x.replace(a,b,n if n else -1)

CSS_COMMON=".footer-bottom a{text-decoration:underline;text-underline-offset:3px}.footer-bottom a:hover{color:#fff}\n"
P={}
for n,d in loc.items():
    x=open(U+n+'.html',encoding='utf8').read()
    pre='' if d=='home' else '../home/'
    x=x.replace('>Contáctanos aquí<','>Contáctanos<')
    x=x.replace('aria-current="true"','aria-current="page"')
    x=rep(x,'<span>Términos · Privacidad · Seguridad de datos</span>',f'<span>Términos · Privacidad · Seguridad de datos · <a href="{pre}mapa_sitio.html">Mapa del sitio</a></span>')
    x=rep(x,'</style>',CSS_COMMON+'</style>')
    # h1 único por página
    if n in('servicios','casos_exito','nosotros','clientes','blog','contacto'):
        x=rep(x,r'<h2 (class="section-title" id="[\w-]+-title">.*?)</h2>',r'<h1 \1</h1>',rx=True)
    P[n]=x

# ---------- HOME
x=P['home']
x=rep(x,r'<div class="hero-visual" aria-hidden="true">\s*<div class="hero-visual">.*?</div>\s*</div>',
'''<div class="hero-visual" aria-hidden="true">
        <picture>
          <source media="(min-width: 850px)" type="image/webp" srcset="../assets/Home/fondo.webp">
          <source media="(max-width: 849px)" type="image/webp" srcset="../assets/Home/fondo-480.webp">
          <img src="../assets/Home/fondo.png" alt="" loading="eager" decoding="async">
        </picture>
      </div>''',rx=True)
x=rep(x,'</style>','''.demo-video{width:100%;max-width:760px;margin-inline:auto;border-radius:12px;background:#17204d}
.demo-note{margin-top:12px;color:var(--muted);font-size:13px;text-align:center}
</style>''')
x=rep(x,'</section>\n\n</main>','''</section>

  <!-- Video demostrativo con subtítulos -->
  <section class="section section--tint" id="demo" aria-labelledby="demo-title">
    <div class="wrap">
      <header class="section-head">
        <h2 class="section-title" id="demo-title">Mira un dashboard en acción</h2>
        <p class="section-intro">Un recorrido de 60 segundos por un tablero real: de las fuentes de datos al indicador que mueve una decisión.</p>
      </header>
      <figure>
        <video class="demo-video" controls preload="metadata" poster="../assets/Home/poster.webp" width="760" height="428">
          <source src="../assets/Home/demo.webm" type="video/webm">
          <source src="../assets/Home/demo.mp4" type="video/mp4">
          <track kind="subtitles" srclang="es" label="Español" src="../assets/Home/demo-es.vtt" default>
          <p>Tu navegador no reproduce video. <a href="../assets/Home/demo.mp4">Descarga el video de demostración</a>.</p>
        </video>
        <figcaption class="demo-note">Video con subtítulos en español. Activa o desactiva los subtítulos desde el reproductor.</figcaption>
      </figure>
    </div>
  </section>

</main>''')
P['home']=x

# ---------- PORTAL
x=P['portal']
x=rep(x,'<section class="graphic" aria-hidden="true">','<div class="graphic" aria-hidden="true">')
x=rep(x,r'(<div class="graphic" aria-hidden="true">.*?)</section>',r'\1</div>',rx=True)
x=rep(x,'<form class="login" novalidate>','<form class="login">')
x=rep(x,'<input id="portal-email" type="email" autocomplete="email">','<input id="portal-email" name="email" type="email" autocomplete="email" required placeholder="nombre@empresa.pe">')
x=rep(x,'<input id="portal-pass" type="password" autocomplete="current-password">','<input id="portal-pass" name="password" type="password" autocomplete="current-password" required minlength="8" placeholder="Mínimo 8 caracteres">')
P['portal']=x

# ---------- SERVICIOS
x=P['servicios']
for t,l in [('Dashboards &amp; BI','Ver detalle de Dashboards y BI'),('Analítica descriptiva','Ver detalle de Analítica descriptiva'),('Machine Learning aplicado','Ver detalle de Machine Learning aplicado'),('MLOps &amp; automatización','Ver detalle de MLOps y automatización'),('Data Strategy &amp; Governance','Ver detalle de Data Strategy y Governance')]:
    x=rep(x,rf'(<h3 class="card-title">{re.escape(t)}</h3>.*?<button class="card-link" type="button")>',rf'\1 aria-label="{l}">',rx=True)
x=rep(x,r'(<h3 class="card-title">Producto SaaS vertical</h3>.*?<button class="card-link" type="button")>',r'\1 aria-label="Unirme a la lista de espera del producto SaaS vertical">',rx=True)
x=rep(x,'</style>','''.table-wrap{overflow-x:auto;border:1px solid #e1e6ea;border-radius:12px;background:#fff}
.table-wrap:focus-visible{outline:2px solid var(--teal);outline-offset:3px}
.rates{width:100%;min-width:640px;border-collapse:collapse;font-size:14px}
.rates caption{padding:16px 18px;text-align:left;font:700 16px/1.3 var(--serif)}
.rates th,.rates td{padding:12px 18px;text-align:left;border-top:1px solid var(--line);vertical-align:top}
.rates thead th{background:var(--bg);color:var(--navy);font-size:13px}
.rates tbody th[scope="rowgroup"]{background:#f9fbfc;color:var(--ink-soft);font-weight:700;border-right:1px solid var(--line)}
.rates tbody th[scope="row"]{font-weight:700}
.rates tfoot td{background:var(--bg);color:var(--muted);font-size:13px}
</style>''')
x=rep(x,r'</section>\s*</main>','''</section>

  <!-- Tarifas orientativas (tabla de datos) -->
  <section class="section" id="tarifas" aria-labelledby="tarifas-title">
    <div class="wrap">
      <header class="section-head">
        <h2 class="section-title" id="tarifas-title">Inversión y plazos de referencia</h2>
        <p class="section-intro">Compara qué entrega cada servicio, en cuánto tiempo y con qué inversión aproximada. El valor final se define en el diagnóstico gratuito.</p>
      </header>
      <div class="table-wrap" role="region" aria-labelledby="rates-caption" tabindex="0">
        <table class="rates">
          <caption id="rates-caption">Comparativo de servicios de DataForge: entregable, plazo e inversión referencial</caption>
          <thead>
            <tr>
              <th scope="col">Línea</th>
              <th scope="col">Servicio</th>
              <th scope="col">Entregable principal</th>
              <th scope="col">Plazo estimado</th>
              <th scope="col">Inversión referencial</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="rowgroup" rowspan="2">Analítica</th>
              <th scope="row">Dashboards &amp; BI</th>
              <td>Primer tablero conectado a tus fuentes</td>
              <td>2–4 semanas</td>
              <td>Desde US$ 1,500</td>
            </tr>
            <tr>
              <th scope="row">Analítica descriptiva</th>
              <td>Reportes automáticos, KPIs y alertas</td>
              <td>2–3 semanas</td>
              <td>Desde US$ 1,200</td>
            </tr>
            <tr>
              <th scope="rowgroup" rowspan="2">Machine Learning</th>
              <th scope="row">Machine Learning aplicado</th>
              <td>Modelo predictivo validado con tus datos</td>
              <td>4–8 semanas</td>
              <td>Desde US$ 4,000</td>
            </tr>
            <tr>
              <th scope="row">MLOps &amp; automatización</th>
              <td>Pipeline y monitoreo del modelo en producción</td>
              <td>3–6 semanas</td>
              <td>Desde US$ 3,000</td>
            </tr>
            <tr>
              <th scope="rowgroup">Estrategia</th>
              <th scope="row">Data Strategy &amp; Governance</th>
              <td>Auditoría de datos y hoja de ruta</td>
              <td>2–4 semanas</td>
              <td>Desde US$ 2,000</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="5">Valores referenciales en dólares, sin impuestos. El diagnóstico inicial no tiene costo.</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </section>
</main>''',rx=True)
P['servicios']=x

# ---------- CONTACTO
x=P['contacto']
x=rep(x,'</style>','''.fs{grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:22px 56px;min-width:0;margin:0;padding:0;border:0}
.fs legend{grid-column:1/-1;padding:0;margin-bottom:2px;color:var(--muted);font-size:13px;font-weight:700}
.field select{width:100%;padding:8px 0 9px;border:0;border-bottom:1px solid #8b96a8;border-radius:0;background:transparent;color:var(--navy);font:inherit;font-size:14px}
.field select:focus{outline:0;border-bottom-color:var(--navy);box-shadow:0 1px 0 var(--navy)}
.field input:user-invalid,.field textarea:user-invalid,.field select:user-invalid{border-bottom-color:#b3261e}
.hint{margin-top:6px;color:var(--muted);font-size:12px}
.choices{display:flex;flex-wrap:wrap;gap:8px 24px;margin-top:4px}
.choice{display:flex;align-items:center;gap:8px;font-size:14px}
.choice input{width:18px;height:18px;margin:0;accent-color:var(--navy)}
.form-note{grid-column:1/-1;color:var(--muted);font-size:13px}
.form-status{grid-column:1/-1;margin:0;color:var(--teal);font-weight:700}
@media(max-width:700px){.fs{grid-template-columns:1fr;gap:22px}}
</style>''')
FORM='''<form class="contact-form" id="form-contacto">
        <p class="form-note">Los campos con <span aria-hidden="true">*</span><span class="sr-only"> asterisco</span> son obligatorios.</p>
        <fieldset class="fs">
          <legend>Tus datos de contacto</legend>
          <div class="field">
            <label for="nombre">Nombre y apellido *</label>
            <input id="nombre" name="nombre" type="text" autocomplete="name" required minlength="3" maxlength="60" pattern="[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' ]{3,60}" title="Solo letras y espacios, entre 3 y 60 caracteres" placeholder="Escribe tu nombre y apellido">
          </div>
          <div class="field">
            <label for="telefono">Celular *</label>
            <input id="telefono" name="telefono" type="tel" autocomplete="tel" required inputmode="numeric" maxlength="9" pattern="9[0-9]{8}" title="9 dígitos, empezando con 9" placeholder="987654321">
            <span class="hint">9 dígitos, sin espacios.</span>
          </div>
          <div class="field field--full">
            <label for="correo">Correo corporativo *</label>
            <input id="correo" name="correo" type="email" autocomplete="email" required placeholder="nombre@empresa.pe">
          </div>
        </fieldset>
        <fieldset class="fs">
          <legend>Sobre tu empresa</legend>
          <div class="field">
            <label for="rubro">Rubro *</label>
            <select id="rubro" name="rubro" required>
              <option value="">Selecciona una opción</option>
              <option value="retail">Retail</option>
              <option value="salud">Salud</option>
              <option value="logistica">Logística</option>
              <option value="fintech">Fintech</option>
              <option value="otro">Otro</option>
            </select>
          </div>
          <div class="field">
            <label for="empleados">Número de empleados *</label>
            <input id="empleados" name="empleados" type="number" required min="20" max="200" step="1" inputmode="numeric" placeholder="Entre 20 y 200">
            <span class="hint">Trabajamos con empresas de 20 a 200 empleados.</span>
          </div>
        </fieldset>
        <fieldset class="fs">
          <legend>Tu consulta</legend>
          <div class="field field--full">
            <span class="hint" id="interes-label" style="margin:0 0 4px">¿Qué servicio te interesa? *</span>
            <div class="choices" role="radiogroup" aria-labelledby="interes-label">
              <label class="choice"><input type="radio" name="interes" value="dashboards" required> Dashboards &amp; BI</label>
              <label class="choice"><input type="radio" name="interes" value="ml"> Machine Learning</label>
              <label class="choice"><input type="radio" name="interes" value="estrategia"> Data Strategy</label>
            </div>
          </div>
          <div class="field">
            <label for="fecha">Fecha preferida para el diagnóstico</label>
            <input id="fecha" name="fecha" type="date">
          </div>
          <div class="field field--full">
            <label for="mensaje">¿Cómo podemos ayudarte? *</label>
            <textarea id="mensaje" name="mensaje" rows="3" required minlength="10" maxlength="500" placeholder="Cuéntanos sobre los desafíos en analytics y machine learning en tu empresa."></textarea>
          </div>
          <div class="field field--full">
            <label class="choice" style="font:400 14px/1.4 var(--sans)"><input type="checkbox" name="privacidad" required> Acepto la política de privacidad y el tratamiento de mis datos. *</label>
          </div>
        </fieldset>
        <p class="form-status" id="form-status" role="status" aria-live="polite"></p>
        <div class="form-actions"><button class="btn btn--orange" type="submit">Solicitar diagnóstico</button></div>
      </form>'''
x=rep(x,r'<form class="contact-form" novalidate>.*?</form>',FORM.replace('\\','\\\\'),rx=True)
x=rep(x,'</style>','.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}\n</style>')
x=rep(x,"  document.querySelector('.contact-form')?.addEventListener('submit', e => e.preventDefault());",
'''  const form = document.getElementById('form-contacto');
  const fecha = document.getElementById('fecha');
  if (fecha) {  /* solo fechas desde hoy hasta 60 días */
    const iso = d => d.toISOString().slice(0, 10);
    const hoy = new Date(), max = new Date(); max.setDate(hoy.getDate() + 60);
    fecha.min = iso(hoy); fecha.max = iso(max);
  }
  form?.addEventListener('submit', e => {
    e.preventDefault();   /* el navegador ya validó los campos antes de llegar aquí */
    document.getElementById('form-status').textContent = 'Gracias. Recibimos tu solicitud y te contactaremos en 24 horas.';
    form.reset();
  });''')
P['contacto']=x

for n,d in loc.items():
    os.makedirs(O+d,exist_ok=True)
    open(O+d+'/'+n+'.html','w',encoding='utf8').write(P[n])

# ---------- MAPA DEL SITIO (a partir de contacto.html)
x=P['contacto']
x=rep(x,r'<title>.*?</title>','<title>Mapa del sitio | DataForge</title>',rx=True)
x=rep(x,r'<main id="contenido">.*?</main>','''<main id="contenido">
  <section class="section" id="mapa" aria-labelledby="mapa-title">
    <div class="wrap">
      <header class="section-head">
        <h1 class="section-title" id="mapa-title">Mapa del sitio</h1>
        <p class="section-intro">Todas las páginas de DataForge en un solo lugar.</p>
      </header>
      <nav aria-label="Mapa del sitio">
        <ul class="sitemap">
          <li><a href="home.html#inicio">Inicio</a>
            <ul>
              <li><a href="home.html#demo">Video demostrativo</a></li>
            </ul>
          </li>
          <li><a href="../servicios/servicios.html#servicios">Servicios</a>
            <ul>
              <li><a href="../servicios/servicios.html#servicios">Dashboards &amp; BI, Analítica descriptiva, Machine Learning, MLOps y Data Strategy</a></li>
              <li><a href="../servicios/servicios.html#tarifas">Inversión y plazos de referencia</a></li>
            </ul>
          </li>
          <li><a href="../casos_exito/casos_exito.html#casos-exito">Casos de éxito</a>
            <ul><li>Retail, Salud y Logística</li></ul>
          </li>
          <li><a href="../nosotros/nosotros.html#nosotros">Nosotros</a>
            <ul><li>Equipo y metodología de trabajo</li></ul>
          </li>
          <li><a href="../clientes/clientes.html#clientes">Clientes</a></li>
          <li><a href="../blog/blog.html#blog">Blog</a></li>
          <li><a href="contacto.html#contacto">Contacto</a></li>
          <li><a href="portal.html">Portal cliente</a></li>
          <li><a href="mapa_sitio.html">Mapa del sitio</a></li>
        </ul>
      </nav>
    </div>
  </section>
</main>''',rx=True)
x=rep(x,'</style>','.sitemap{display:grid;gap:14px;font-size:16px}.sitemap ul{display:grid;gap:8px;margin-top:8px;padding-left:22px;border-left:2px solid var(--line);color:var(--muted);font-size:14px}.sitemap a{color:var(--navy);font-weight:700;text-decoration:underline;text-underline-offset:3px}.sitemap ul a{font-weight:400}\n</style>')
open(O+'home/mapa_sitio.html','w',encoding='utf8').write(x)

# ---------- subtítulos
os.makedirs(O+'assets/Home',exist_ok=True)
open(O+'assets/Home/demo-es.vtt','w',encoding='utf8').write('''WEBVTT

00:00:00.000 --> 00:00:06.000
Así se ve un dashboard de DataForge conectado a las fuentes de tu empresa.

00:00:06.000 --> 00:00:14.000
Los indicadores clave se actualizan solos, sin reportes manuales.

00:00:14.000 --> 00:00:24.000
Las alertas tempranas avisan cuando una métrica se desvía de lo esperado.

00:00:24.000 --> 00:00:34.000
Desde aquí tu equipo decide con datos, no por intuición.
''')
print('OK')
