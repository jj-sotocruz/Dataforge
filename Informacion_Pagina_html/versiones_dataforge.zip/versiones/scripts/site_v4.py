import re,os,glob,math
from PIL import Image,ImageDraw
R='/mnt/user-data/outputs/dataforge_html/'
rd=lambda p:open(R+p,encoding='utf8').read()
def wr(p,s): open(R+p,'w',encoding='utf8').write(s)
# ---------- radio de esquina de las imágenes originales
o=Image.open('/mnt/user-data/uploads/card1.png').convert('RGBA'); row=[o.getpixel((x,0))[3] for x in range(o.width)]
rad=next(i for i,a in enumerate(row) if a>200); print('radio de esquina original (px a 540):',rad)
def rounded(im,r):
    k=4; m=Image.new('L',(im.width*k,im.height*k),0); ImageDraw.Draw(m).rounded_rectangle([0,0,im.width*k-1,im.height*k-1],r*k,fill=255)
    im=im.convert('RGBA'); im.putalpha(m.resize(im.size,Image.LANCZOS)); return im
def bg(W,H):
    im=Image.new('RGB',(W,H)); d=ImageDraw.Draw(im)
    for y in range(H): d.line([(0,y),(W,y)],fill=(12+int(16*y/H),32+int(34*y/H),96+int(44*y/H)))
    return im,d
NAVY=(12,32,96);OR=(255,157,24);CY=(0,188,212);WH=(255,255,255)
# card3: machine learning (datos -> modelo -> predicción)
W,H=1080,580; im,d=bg(W,H)
import random; random.seed(4)
for _ in range(16):
    x,y=random.randint(70,250),random.randint(110,470); d.ellipse([x-11,y-11,x+11,y+11],fill=CY if random.random()<.6 else WH)
layers=[(430,[190,290,390]),(540,[140,240,340,440]),(650,[190,290,390])]
for (x0,ys0),(x1,ys1) in zip(layers,layers[1:]):
    for a in ys0:
        for b in ys1: d.line([(x0,a),(x1,b)],fill=(120,160,215),width=3)
for i,(x,ys) in enumerate(layers):
    for y in ys: d.ellipse([x-24,y-24,x+24,y+24],fill=OR if i==1 else WH,outline=CY,width=4)
for x0,x1 in ((270,380),(700,770)): d.line([(x0,290),(x1,290)],fill=WH,width=6); d.polygon([(x1,290),(x1-22,276),(x1-22,304)],fill=WH)
d.rounded_rectangle([790,150,1020,430],30,fill=WH)
pts=[(830,370),(880,330),(920,345),(960,270),(990,210)]; d.line(pts,fill=NAVY,width=9,joint='curve')
for x,y in pts[:-1]: d.ellipse([x-9,y-9,x+9,y+9],fill=NAVY)
d.ellipse([pts[-1][0]-18,pts[-1][1]-18,pts[-1][0]+18,pts[-1][1]+18],fill=OR)
for x in (830,880,920,960): d.rounded_rectangle([x-12,395,x+12,410],4,fill=(214,222,232))
rounded(im.resize((540,290),Image.LANCZOS),rad).save(R+'assets/Blog/card3.webp','WEBP',quality=84,method=6)
# card4: checklist + fuentes conectadas (con esquinas redondeadas)
im,d=bg(W,H)
d.rounded_rectangle([140,70,700,510],28,fill=WH)
for i in range(4):
    y=130+i*95; d.rounded_rectangle([190,y,238,y+48],10,fill=OR); d.line([(202,y+25),(212,y+36),(228,y+14)],fill=WH,width=7)
    d.rounded_rectangle([270,y+8,270+[330,270,300,220][i],y+22],7,fill=(214,222,232)); d.rounded_rectangle([270,y+30,270+[220,200,180,260][i]-60,y+40],5,fill=(232,237,243))
pts=[(800,140),(930,260),(820,380),(960,450)]
for a,c in zip(pts,pts[1:]): d.line([a,c],fill=CY,width=8)
for x,y in pts: d.ellipse([x-26,y-26,x+26,y+26],fill=OR,outline=WH,width=5)
rounded(im.resize((540,290),Image.LANCZOS),rad).save(R+'assets/Blog/card4.webp','WEBP',quality=84,method=6)
# ---------- blog: fecha en el encabezado
b=rd('blog/blog.html')
if 'Última actualización' not in b:
    b=b.replace('optimicen sus procesos.</p>\n        </header>','optimicen sus procesos.</p>\n          <p>Última actualización: <time datetime="2026-08-12">12 de agosto de 2026</time></p>\n        </header>',1); assert 'Última actualización' in b
wr('blog/blog.html',b)
# ---------- casos: sector en mayúsculas (formato original), mismo tamaño de encabezado
c=rd('casos_exito/casos_exito.html')
c=re.sub(r'(<h2 id="caso-[a-z]+">)([^<]+)(</h2>)',lambda m:m.group(1)+m.group(2).upper()+m.group(3),c); wr('casos_exito/casos_exito.html',c)
# ---------- tabla visible sin CSS
s=rd('servicios/servicios.html'); s=s.replace('<table>','<table border="1">',1); assert 'border="1"' in s; wr('servicios/servicios.html',s)
# ---------- páginas de servicio
SVG='''<svg width="320" height="190" viewBox="0 0 320 190" role="img" aria-labelledby="construccion-title">
          <title id="construccion-title">Página en construcción</title>
          <rect x="3" y="3" width="314" height="184" rx="44" ry="44" fill="#f4f7f9" stroke="#0c2060" stroke-width="4"></rect>
          <text x="160" y="103" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="25" font-weight="bold" fill="#0c2060">Página en construcción</text>
        </svg>'''
for f in glob.glob(R+'servicios/*.html'):
    n=os.path.basename(f)
    if n=='servicios.html': continue
    s=open(f,encoding='utf8').read(); name=re.search(r'<h1 id="servicio-title">(.*?)</h1>',s).group(1); plain=re.search(r'<!-- (.*?) -->',s).group(1)
    main=f'''<main id="contenido">
      <!-- {plain} -->
      <section id="servicio" aria-labelledby="servicio-title">
        <h1 id="servicio-title">{name}</h1>
        <p><img src="../assets/Header/logo.webp" alt="DataForge" width="200" height="52"></p>
        <p>
        {SVG}
        </p>
        <p><a href="servicios.html#servicios">Volver a servicios</a></p>
      </section>
    </main>'''
    s=re.sub(r'<main id="contenido">.*?</main>',lambda m:main,s,flags=re.S); open(f,'w',encoding='utf8').write(s)
print('ok')
