import numpy as np, subprocess, math
from PIL import Image, ImageDraw, ImageFont
W,H,FPS,DUR=1920,1080,24,36
BG=(244,247,249);WHITE=(255,255,255);NAVY=(12,32,96);ORANGE=(255,157,24);TEAL=(0,124,145);RED=(200,40,50);GRAY=(96,112,135);LINE=(225,231,236);GREEN=(30,140,90)
FD='/usr/share/fonts/truetype/crosextra/'
def F(s,b=False): return ImageFont.truetype(FD+('Carlito-Bold.ttf' if b else 'Carlito-Regular.ttf'),s)
f={k:F(s,b) for k,(s,b) in dict(t=(36,1),h=(30,1),l=(24,0),lb=(24,1),v=(70,1),s=(21,0),m=(28,1),big=(64,1)).items()}
from PIL import ImageChops
def trim(p):
    im=Image.open(p).convert('RGBA'); bg=Image.new('RGBA',im.size,(255,255,255,255)); flat=Image.alpha_composite(bg,im).convert('RGB')
    box=ImageChops.difference(flat,Image.new('RGB',im.size,(255,255,255))).point(lambda v:255 if v>12 else 0).getbbox()
    return flat.crop(box).convert('RGBA')
logo=trim('/home/claude/logo.png'); icon=trim('/home/claude/icono.png').resize((64,64),Image.LANCZOS)
ease=lambda x:(lambda x:x*x*(3-2*x))(min(1,max(0,x)))
def mix(c,bg,a): return tuple(int(bg[i]+(c[i]-bg[i])*a) for i in range(3))
rng=np.random.default_rng(7)
hist=np.linspace(96,121,30)+6*np.sin(np.arange(30)/2.3)+rng.normal(0,2.2,30)
fc=hist[-1]+np.arange(1,15)*0.95; band=np.linspace(3,10,14)
X0,X1,Y0,Y1,YMIN,YMAX,ND=130,1150,490,950,80,150,44
px=lambda d:X0+(X1-X0)*d/(ND-1); py=lambda v:Y1-(Y1-Y0)*(v-YMIN)/(YMAX-YMIN)
def dash(d,pts,col,w,on=14,off=10):
    for a,b in zip(pts,pts[1:]):
        L=math.dist(a,b); n=int(L//(on+off))+1
        for k in range(n):
            s=k*(on+off)/L; e=min(1,(k*(on+off)+on)/L)
            if s<1: d.line([(a[0]+(b[0]-a[0])*s,a[1]+(b[1]-a[1])*s),(a[0]+(b[0]-a[0])*e,a[1]+(b[1]-a[1])*e)],fill=col,width=w)
def card(d,box,a,bg=BG):
    d.rounded_rectangle(box,18,fill=mix(WHITE,bg,a),outline=mix(LINE,bg,a),width=2)
def frame(t):
    im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    # barra superior
    a=ease((t-1.8)/0.6)
    d.rectangle([0,0,W,96],fill=mix(NAVY,BG,a)); 
    if a>0.5:
        d.rounded_rectangle([34,12,110,84],12,fill=WHITE); im.paste(icon,(40,16),icon); d.text((134,48),'Panel de ventas · Tienda en línea',font=f['t'],fill=WHITE,anchor='lm')
        d.rounded_rectangle([1560,28,1880,68],20,outline=ORANGE,width=2); d.text((1720,48),'Datos ficticios',font=f['s'],fill=ORANGE,anchor='mm')
    # fuentes conectadas
    a=ease((t-2.4)/0.6)
    if a>0:
        d.text((60,135),'Fuentes conectadas',font=f['lb'],fill=mix(GRAY,BG,a),anchor='lm')
        for i,(n,t0) in enumerate([('ERP',3.2),('Tienda web',4.0),('CRM',4.8)]):
            x=330+i*190; on=ease((t-t0)/0.4)
            d.rounded_rectangle([x,112,x+170,158],23,fill=mix(TEAL,WHITE,on),outline=mix(TEAL,LINE,max(on,.3))*1 if False else mix((TEAL if on>0 else LINE),BG,a),width=2)
            d.text((x+85,135),n,font=f['l'],fill=WHITE if on>.5 else mix(GRAY,BG,a),anchor='mm')
    # tarjetas KPI
    kp=[('Ventas del mes',482,'S/ {:,.0f} mil','+9.4%',GREEN),('Pedidos',3240,'{:,.0f}','+6.1%',GREEN),('Margen',24.8,'{:.1f}%','+1.2 pts',GREEN),('Satisfacción',4.6,'{:.1f} / 5','+0.2',GREEN)]
    for i,(lab,val,fmt,dl,col) in enumerate(kp):
        a=ease((t-(2.8+0.35*i))/0.6); 
        if a<=0: continue
        x=60+i*455; y=190+(1-a)*24
        card(d,[x,y,x+435,y+170],a)
        p=ease((t-6)/4); live=1+0.003*max(0,math.floor((t-10.5)/1.4)) if t>10.5 else 1
        v=val*p*live; txt=fmt.format(v)
        d.text((x+28,y+40),lab,font=f['l'],fill=mix(GRAY,WHITE,a),anchor='lm')
        d.text((x+28,y+105),txt,font=f['v'],fill=mix(NAVY,WHITE,a),anchor='lm')
        if p>0.9: d.rounded_rectangle([x+290,y+22,x+410,y+58],18,fill=(222,243,232)); d.text((x+350,y+40),dl,font=f['s'],fill=GREEN,anchor='mm')
    # gráfico de líneas
    a=ease((t-5)/0.7)
    if a>0:
        card(d,[60,390,1180,1020],a); d.text((100,432),'Ventas diarias (S/ miles)',font=f['h'],fill=mix(NAVY,WHITE,a),anchor='lm')
        for v in (80,100,120,140):
            d.line([(X0,py(v)),(X1,py(v))],fill=mix(LINE,WHITE,a),width=2); d.text((X0-14,py(v)),str(v),font=f['s'],fill=mix(GRAY,WHITE,a),anchor='rm')
        for dd in (0,9,19,29,43):
            d.text((px(dd),Y1+28),str(dd+1) if dd<43 else '44',font=f['s'],fill=mix(GRAY,WHITE,a),anchor='mm')
        d.text((X1,Y1+62),'días',font=f['s'],fill=mix(GRAY,WHITE,a),anchor='rm')
        dash(d,[(px(0),py(118)),(px(ND-1),py(118))],mix(NAVY,WHITE,a),3)
        d.text((X0+8,py(118)-16),'Meta diaria',font=f['s'],fill=mix(NAVY,WHITE,a),anchor='lm')
        p=ease((t-6.5)/7); n=1+p*29; k=int(n); pts=[(px(i),py(hist[i])) for i in range(k)]
        if k<30: fr=n-k; pts.append((px(k)+(px(k+1)-px(k))*fr-(px(k+1)-px(k)),py(hist[k-1]+(hist[k]-hist[k-1])*fr))) if False else pts.append((px(k-1+fr),py(hist[k-1]+(hist[k]-hist[k-1])*fr)))
        if len(pts)>1: d.line(pts,fill=ORANGE,width=6,joint='curve')
        if pts: d.ellipse([pts[-1][0]-9,pts[-1][1]-9,pts[-1][0]+9,pts[-1][1]+9],fill=ORANGE,outline=WHITE,width=3)
        # proyección
        q=ease((t-24.6)/7)
        if q>0:
            m=int(q*14); m=max(m,1); xs=[29]+list(range(30,30+m)); ys=[hist[-1]]+list(fc[:m])
            up=[(px(x),py(y+(0 if x==29 else band[x-30]))) for x,y in zip(xs,ys)]; lo=[(px(x),py(y-(0 if x==29 else band[x-30]))) for x,y in zip(xs,ys)]
            d.polygon(up+lo[::-1],fill=(204,232,237))
            dash(d,[(px(x),py(y)) for x,y in zip(xs,ys)],TEAL,6)
            d.text((px(37),py(150)+8),'Proyección ML',font=f['lb'],fill=TEAL,anchor='mm')
    # barras por región
    a=ease((t-14)/0.7)
    if a>0:
        card(d,[1240,390,1860,700],a); d.text((1272,432),'Ventas por región vs meta',font=f['h'],fill=mix(NAVY,WHITE,a),anchor='lm')
        bx0,bx1,by0,by1=1290,1830,470,640; sc=lambda v:by1-(by1-by0)*(v-50)/(125-50)
        dash(d,[(bx0,sc(100)),(bx1,sc(100))],NAVY,3); d.text((bx1,sc(100)-14),'Meta 100%',font=f['s'],fill=NAVY,anchor='rm')
        for i,(n,v) in enumerate([('Lima',112),('Sur',104),('Centro',101),('Norte',88)]):
            p=ease((t-14.6-0.4*i)/1.6); x=bx0+30+i*130; top=sc(50+(v-50)*p)
            col=TEAL
            if n=='Norte' and t>18.5: col=mix(RED,TEAL,1) if (math.sin(t*7)>-0.3) else (230,120,125)
            d.rounded_rectangle([x,top,x+80,by1],8,fill=mix(col,WHITE,a)) if by1-top>8 else None
            d.text((x+40,by1+22),n,font=f['s'],fill=mix(GRAY,WHITE,a),anchor='mm')
            if p>.95 and by1-top>40: d.text((x+40,top+24),f'{v}%',font=f['lb'],fill=WHITE,anchor='mm')
    # alerta / proyección
    al=ease((t-18.8)/0.8)*(1-ease((t-23.6)/0.6))
    if al>0:
        x=1240+(1-ease((t-18.8)/0.8))*40; card(d,[x,730,x+620,1020],al)
        d.rounded_rectangle([x,730,x+14,1020],6,fill=mix(RED,WHITE,al)); r=11+4*math.sin(t*6)
        d.ellipse([x+52-r,790-r,x+52+r,790+r],fill=mix(RED,WHITE,al)); d.text((x+84,790),'Alerta temprana',font=f['t'],fill=mix(RED,WHITE,al),anchor='lm')
        for j,s in enumerate(['Las ventas de la región Norte están','12% por debajo de la meta semanal.','','Sugerencia: reforzar stock y campañas','en la zona esta semana.']):
            d.text((x+52,850+j*36),s,font=f['l'],fill=mix(NAVY,WHITE,al),anchor='lm')
    pr=ease((t-24.2)/0.8)
    if pr>0:
        x=1240; card(d,[x,730,x+620,1020],pr); d.rounded_rectangle([x,730,x+14,1020],6,fill=mix(TEAL,WHITE,pr))
        d.text((x+52,790),'Proyección (machine learning)',font=f['h'],fill=mix(TEAL,WHITE,pr),anchor='lm')
        d.text((x+52,880),'+8% de ventas',font=f['big'],fill=mix(NAVY,WHITE,pr),anchor='lm')
        d.text((x+52,945),'en las próximas 2 semanas · confianza 91%',font=f['l'],fill=mix(GRAY,WHITE,pr),anchor='lm')
        d.text((x+52,985),'Tu equipo decide con datos, no por intuición.',font=f['l'],fill=mix(NAVY,WHITE,pr),anchor='lm')
    # intro y cierre
    ov=0
    if t<2.4: ov=1 if t<1.7 else 1-ease((t-1.7)/0.7)
    if t>33.4: ov=ease((t-33.4)/0.9)
    if ov>0:
        c=Image.new('RGB',(W,H),WHITE); lw=900; l=logo.resize((lw,round(logo.height*lw/logo.width)),Image.LANCZOS)
        fade=ease(t/0.7) if t<2.4 else 1
        c.paste(l,((W-lw)//2,380),l); dc=ImageDraw.Draw(c)
        sub='Así se ve un dashboard conectado a tus datos' if t<5 else 'Tus datos ya saben qué hacer.'
        dc.text((W//2,690),sub,font=f['t'],fill=GRAY,anchor='mm')
        if t<1: c=Image.blend(Image.new('RGB',(W,H),WHITE),c,fade)
        im=Image.blend(im,c,ov)
    return im.resize((1280,720),Image.LANCZOS)
if __name__=='__main__':
    import sys
    p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-','-c:v','libx264','-pix_fmt','yuv420p','-crf','23','-preset','medium','-movflags','+faststart','/mnt/user-data/outputs/dataforge/assets/Home/demo.mp4'],stdin=subprocess.PIPE)
    for n in range(FPS*DUR):
        t=n/FPS; im=frame(t); p.stdin.write(im.tobytes())
    p.stdin.close(); p.wait()
    for name,tt in (('poster',30.5),('f10',10),('f20',20)): frame(tt).save(f'/home/claude/{name}.png')
    print('listo')
