import re
from xml.sax.saxutils import escape
p='word/document.xml'
x=open(p,encoding='utf8').read()

R={
# ---- Ficha técnica
10:"Sitio Web Corporativo para DataForge Analytics: analítica de datos, Machine Learning y dashboards para PyMEs",
12:"[COMPLETAR: Apellidos y Nombres completos]",
14:"[COMPLETAR: Código de estudiante]",
16:"[COMPLETAR: Desarrollo de Sistemas de Información / Diseño Web]",
18:"[COMPLETAR: Ciclo 1 — turno y horario]",
20:"[COMPLETAR: Nombre del docente evaluador]",
22:"https://dataforge.pe (dominio propuesto, desplegado en Vercel) — [COMPLETAR: URL real publicada]",
24:"[COMPLETAR: URL del repositorio en GitHub con home.html y carpetas assets/, servicios/, casos_exito/, nosotros/, clientes/, blog/]",
# ---- 1.1
31:"Se desarrolla y prueba el sitio en Google Chrome y Microsoft Edge, ambos basados en Blink. Blink interpreta el HTML5 definido por el estándar vivo de WHATWG, por lo que la estructura de home.html (header, nav, main, section, footer) se renderiza sin ajustes. Las funciones modernas de CSS usadas (grid, flexbox, :focus-visible, clamp(), scroll-padding-top, text-wrap) están soportadas de forma nativa; para la altura de pantalla completa se declara primero 100vh y luego 100svh como mejora progresiva.",
33:"Firefox usa el motor Gecko, que implementa los mismos estándares abiertos (HTML Living Standard, CSS Grid, Flexbox). Las reglas de home.html no dependen de prefijos propietarios, así que Gecko aplica el mismo diseño: header fijo (position: sticky), hero en dos columnas y menú adaptable. El único aspecto a vigilar es text-wrap: balance, que en versiones antiguas se ignora sin romper el diseño (degradación elegante).",
35:"Safari (motor WebKit) en iPhone, iPad y Mac es el entorno móvil más exigente. El sitio declara <meta name=\"viewport\"> y la regla -webkit-text-size-adjust: 100% para evitar el reescalado automático de texto en iOS. Se emplea 100svh con 100vh de respaldo, porque la barra de direcciones de Safari móvil altera el alto visible. Por debajo de 980 px el menú pasa a modo hamburguesa y por debajo de 850 px el hero se apila en una columna. [COMPLETAR: dispositivo y versión de Safari/iOS con que lo probaste].",
37:"El sitio se escribe con HTML5 estándar y CSS sin prefijos propietarios (la única excepción es -webkit-font-smoothing, de carácter cosmético). Al apoyarse en el estándar y no en comportamientos particulares de un navegador, el mismo código funciona en Blink, Gecko y WebKit. Las funciones más nuevas se usan como mejora progresiva (valor de respaldo primero, valor moderno después), de modo que un navegador que no las reconoce muestra una versión algo más simple, pero íntegra y usable.",
# ---- 1.2
40:"DataForge Analytics es una consultora boutique de analítica de datos, Machine Learning y dashboards dirigida a PyMEs de 20 a 200 empleados en retail, salud, logística y fintech. Estas empresas generan muchos datos pero no tienen equipo de analítica, y deciden por intuición. El portal atiende a dos perfiles: el decisor de negocio (gerente o dueño), que busca valor, resultados medibles y costos, y el perfil técnico (jefe de TI), que busca viabilidad, stack y seguridad. Por eso el inicio comunica la propuesta de valor en segundos (\"Tus datos ya saben qué hacer\"), muestra cifras de confianza (40+ proyectos, 98% de satisfacción, 2–4 semanas al primer dashboard) y ofrece dos llamadas a la acción: solicitar un diagnóstico gratis y ver servicios.",
42:"[INICIO: home.html — hero, propuesta de valor y métricas]",
43:"├── [Servicios: servicios/servicios.html — Dashboards & BI, Analítica descriptiva, Machine Learning, MLOps, Data Strategy]",
44:"├── [Casos de éxito: casos_exito/casos_exito.html — Retail, Salud, Logística]",
45:"├── [Nosotros: nosotros/nosotros.html — Equipo y Metodología]",
46:"├── [Clientes: clientes/clientes.html  |  Blog / Recursos: blog/blog.html — Artículos y Guías]",
47:"└── [Contacto: contacto.html (formulario y agenda de demo)  |  Portal cliente: portal.html (login)]",
50:"El menú principal (nav con aria-label=\"Principal\") está presente en todas las páginas y enlaza a Servicios, Casos de éxito, Nosotros, Clientes y Blog, de modo que cada sección principal queda a 1 clic desde el inicio. Los servicios y casos individuales cuelgan de su página padre y quedan a 2 clics como máximo. El botón \"Contáctanos aquí\" aparece en el header y \"Solicitar diagnóstico gratis\" en el hero, así que la conversión principal está a 1 clic. El pie de página repite los enlaces de Servicios, Casos de éxito y Nosotros como segunda vía de acceso. Ningún contenido clave supera los 3 clics.",
# ---- 1.3
53:"Según la propuesta, el sitio se despliega en Vercel Pro (plan contratado, US$ 20/mes) con despliegue continuo conectado al repositorio y una red de distribución de contenido (CDN) global. El contenido se sirve desde nodos cercanos al visitante, lo que reduce la latencia, y la plataforma ofrece alta disponibilidad 24/7 sin administrar servidores propios. Cada cambio subido al repositorio se publica automáticamente.",
55:"HTTPS es HTTP sobre TLS (puerto 443). Cifra la comunicación entre el visitante y el sitio, impide que terceros lean o alteren los datos y autentica al servidor. Esto es crítico porque el sitio recoge datos de contacto de empresas y tiene un portal de clientes con login. Además, genera confianza y favorece el posicionamiento en buscadores. El certificado lo gestiona Cloudflare (Let's Encrypt) con renovación automática.",
57:"Dominio propuesto: www.dataforge.pe (registrado en NIC.pe, plan anual de S/ 45). Cuando el usuario escribe el dominio, su equipo consulta un servidor DNS, que lo traduce a la dirección IP del servidor. Para el dominio raíz se usa un registro A que apunta a la IP del hosting, y para el subdominio www un registro CNAME que apunta al dominio de Vercel. El DNS lo administra Cloudflare, que además acelera la carga y protege contra ataques.",
# ---- 1.4
61:"El logotipo (hexágono con nodos conectados) y los íconos de línea geométrica, coherentes con la identidad visual, son gráficos simples de formas y trazos. En SVG pesan pocos KB, se escalan sin pixelarse en pantallas de alta densidad y pueden recolorearse con CSS (los íconos de las tarjetas de servicio usan stroke con variables de color). Estado actual: home.html carga el logo como PNG (assets/Header/logo.png); el objetivo es reemplazarlo por SVG.",
63:"Las fotografías (equipos trabajando con datos, dashboards reales, oficinas) y los fondos del hero y del blog se publican en WebP, con JPG optimizado como respaldo. WebP logra archivos notablemente más livianos que JPG/PNG con calidad visual equivalente, lo que mejora la velocidad de carga y el rendimiento en Lighthouse. Las imágenes bajo el primer pantallazo usan carga diferida (loading=\"lazy\"); el hero se carga de inmediato (loading=\"eager\") por ser el elemento principal.",
65:"La ilustración del hero (assets/Home/fondo.png) y los logotipos de clientes requieren fondo transparente para integrarse sobre el azul navy y los recuadros blancos. Para ello se usa PNG-24 (o WebP con canal alfa, más ligero). Se emplea solo donde la transparencia es necesaria, y no para fotografías.",
67:"Squoosh.app (WebP y JPG con control de calidad), TinyPNG/TinyJPG (PNG) y SVGO/SVGOMG (limpieza de SVG). [COMPLETAR: indica las que realmente usaste y el peso antes/después].",
# ---- 2.1
73:"<!DOCTYPE html> activa el modo estándar y evita el modo de compatibilidad antiguo. <html lang=\"es\"> declara el idioma del documento. <meta charset=\"utf-8\"> fija la codificación para mostrar bien tildes y la ñ. <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"> hace que la página se adapte al ancho del dispositivo móvil. Además, home.html incluye <title>, <meta name=\"description\"> para SEO, <meta name=\"theme-color\"> y el favicon.",
75:"Home.html se organiza con elementos semánticos: <header> con el <nav aria-label=\"Principal\"> para la navegación; <main id=\"contenido\"> para el contenido principal; <section id=\"inicio\" aria-labelledby=\"hero-title\"> para el hero; y <footer> con información y enlaces. Se añade un enlace \"Saltar al contenido\" (skip-link) al inicio. Las secciones siguientes (servicios, casos, nosotros, clientes, blog, contacto) siguen el mismo patrón con <section>, y los casos y entradas del blog usan <article>. Los <div> se limitan a contenedores de diseño.",
76:"<!-- Maquetación semántica real de home.html -->",
77:"<a class=\"skip-link\" href=\"#contenido\">Saltar al contenido</a>",
78:"<header class=\"site-header\"> <nav aria-label=\"Principal\"> ... </nav> </header>",
79:"<main id=\"contenido\">",
80:"  <section id=\"inicio\" aria-labelledby=\"hero-title\"> ... </section>",
81:"</main>",
82:"<footer class=\"site-footer\"> ... </footer>",
83:"<!-- Pendiente: secciones servicios, casos, nosotros, clientes, blog y contacto -->",
84:"<script> /* menú móvil, Escape para cerrar, medición del footer */ </script>",
86:"Cada página tiene un único <h1>. En home.html es \"Tus datos ya saben qué hacer. Nosotros los ponemos a hablar.\", enlazado con aria-labelledby a la sección hero. Los títulos de sección (clase section-title) usan <h2>, y los títulos de tarjetas, pasos y entradas de blog usan <h3>, sin saltar niveles. Los encabezados se eligen por jerarquía de contenido, y el tamaño visual se controla solo con CSS.",
# ---- 2.2
89:"El logotipo usa alt=\"DataForge\", que identifica la marca y, al estar dentro de un enlace, indica su función (ir al inicio). Las fotos del equipo llevarán alt con el nombre y el rol de la persona. Las fotografías del blog, un texto que describa lo que muestran. La ilustración del hero lleva alt=\"DataForge analítica y dashboards\" pero está en un contenedor con aria-hidden=\"true\" por ser decorativa; lo correcto es unificar y dejar alt=\"\" en ese caso, para que los lectores de pantalla la ignoren.",
91:"Se recorre el sitio solo con Tab, Shift+Tab, Enter y Escape. Existe un enlace \"Saltar al contenido\" visible al recibir el foco, un indicador :focus-visible de 2 px con buen contraste (naranja sobre fondos oscuros), y el menú móvil es un <button> con aria-expanded y aria-controls que se cierra con Escape. Los enlaces usan textos descriptivos (\"Solicitar diagnóstico gratis\", \"Ver servicios\", \"Portal cliente\"). Punto de mejora: \"Contáctanos aquí\" conviene sustituirlo por \"Contáctanos\" o \"Agenda una demo\". [COMPLETAR: confirma tu prueba real con teclado].",
93:"El atributo lang=\"es\" indica el idioma principal. Así, NVDA, JAWS y VoiceOver cargan la voz y reglas de pronunciación del español, en lugar de leer las palabras con acento de otro idioma. También ayuda a la corrección ortográfica y a los traductores automáticos. Para términos en inglés (Machine Learning, MLOps, Dashboards), se puede marcar el fragmento con lang=\"en\".",
# ---- 2.3 A
98:"servicios/servicios.html, sección \"Precios orientativos\" — [PENDIENTE: este archivo no forma parte de home.html; implementarlo y ajustar el nombre].",
100:"Se presenta una comparación de los servicios (Dashboards & BI, Analítica descriptiva, Machine Learning, MLOps, Data Strategy) según entregable, plazo y modelo de inversión referencial. La propuesta del caso exige mostrar precios orientativos y tiempos. Son datos con dos dimensiones (servicio y atributo) que el usuario compara, por lo que una tabla permite leerlos por fila y por columna, algo que un párrafo o una lista no permiten con claridad. Para celdas combinadas, se puede agrupar con rowspan las filas de servicios por categoría y con colspan una celda de nota.",
# ---- 2.3 B
109:"contacto.html (enlazado desde el botón \"Contáctanos aquí\" y desde \"Solicitar diagnóstico gratis\") — [PENDIENTE: el formulario aún no está en home.html; el CSS de .contact-form y .field ya está preparado].",
111:"Es el formulario de contacto y solicitud de diagnóstico/demo, que cubre la necesidad de un contacto directo. Recoge nombre, correo, teléfono, empresa, rubro (retail, salud, logística, fintech), número de empleados (mínimo 20, máximo 200 según el público objetivo), fecha preferida de demo, tipo de consulta (radio), aceptación de la política de privacidad (checkbox) y mensaje. Los campos tienen label asociado, placeholder explicativo y validación nativa (required, type=\"email\", pattern para celular peruano 9[0-9]{8}, min/max), lo que previene errores antes de enviar. En el prototipo, el script evita el envío real con preventDefault; en producción se conectaría a HubSpot y Resend.",
# ---- 2.4
120:"El inicio puede incorporar un video corto de demostración de un dashboard con <video controls preload=\"metadata\" poster=\"assets/Home/poster.webp\">, con <source> en MP4 y WebM, y subtítulos en español mediante <track kind=\"subtitles\" srclang=\"es\" label=\"Español\" src=\"subs-es.vtt\" default>, para accesibilidad auditiva. [PENDIENTE: home.html actual no incluye multimedia nativa; agregarlo y adjuntar evidencia].",
122:"Actualmente el hero usa una única <img> en PNG. Se propone sustituirla por <picture> con <source type=\"image/webp\" media=\"(min-width: 850px)\" srcset=\"fondo-960.webp\"> y una versión menor para móvil, con <img> de respaldo, de modo que cada dispositivo descargue el tamaño adecuado. En pantallas de menos de 850 px el hero oculta la ilustración, por lo que en móvil no se descarga la versión grande. [PENDIENTE: implementar y verificar].",
# ---- Parte 3
129:"[COMPLETAR tras ejecutar el validador sobre la URL publicada.] Puntos a revisar en home.html: que exista un único <h1>; que el contenedor .hero-visual no esté duplicado (hay un div anidado con la misma clase); que los atributos alt no sean redundantes con aria-hidden; y que los enlaces relativos (contacto.html, portal.html, ../servicios/...) apunten a archivos existentes.",
134:"[COMPLETAR con el puntaje real, meta mínima 90/100.] Aspectos del código que favorecen la nota: lang=\"es\", títulos y descripción, skip-link, foco visible, botón del menú con aria-label y aria-expanded, textos en navy sobre blanco de alto contraste. Aspectos a vigilar: contraste de los textos secundarios (#607087 y #66738a sobre #f4f7f9), alt redundante en imágenes decorativas y textos de enlace genéricos.",
# ---- Parte 4
137:"Las etiquetas semánticas (header, nav, main, section, article, footer) describen el rol de cada zona, lo que ayuda a los buscadores a interpretar la jerarquía del contenido y mejora el SEO. Además, vuelven el código más legible y fácil de mantener frente a una estructura de div anidados. En DataForge, un único h1 y títulos ordenados refuerzan la propuesta de valor ante el usuario y ante Google.",
139:"La accesibilidad (WCAG) asegura que el sitio pueda ser usado por personas con discapacidad visual, auditiva, motriz o cognitiva. Prácticas como lang, alt, labels, foco visible, navegación con teclado y contraste suficiente amplían la audiencia y benefician a todos. En un sitio corporativo es también una cuestión de profesionalismo y confianza.",
141:"[PERSONALIZAR con tu experiencia.] Borrador: Durante las 7 semanas pasé de pensar la web como un diseño a entenderla como una estructura con significado. Aprendí a partir de un caso real (identificar usuarios, definir contenidos, armar el mapa del sitio y prototipar) antes de escribir código, y a verificar el resultado con herramientas como W3C y Lighthouse. Lo más valioso fue ver que semántica, accesibilidad y rendimiento forman parte del diseño desde el inicio y no un agregado final.",
}
cnt=[-1]
def sub(m):
    cnt[0]+=1
    i=cnt[0]
    if i in R:
        return '<w:t xml:space="preserve">'+escape(R[i])+'</w:t>'
    return m.group(0)
x2=re.sub(r'<w:t(?: [^>]*)?>[^<]*</w:t>',sub,x)
open(p,'w',encoding='utf8').write(x2)
print(len(R),'reemplazos,',cnt[0]+1,'textos')
