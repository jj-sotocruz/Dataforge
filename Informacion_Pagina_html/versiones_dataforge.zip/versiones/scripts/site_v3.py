import re,glob,os
from bs4 import BeautifulSoup
from PIL import Image,ImageDraw
R='/mnt/user-data/outputs/dataforge_html/'
def rd(p): return open(R+p,encoding='utf8').read()
def wr(p,s): open(R+p,'w',encoding='utf8').write(s)
S=[('dashboards-bi','Dashboards &amp; BI','Dashboards y BI','Conectamos tus fuentes (ERP, CRM, Excel, APIs) y diseñamos tableros en Power BI, Looker o Metabase.'),
   ('analitica-descriptiva','Analítica descriptiva','Analítica descriptiva','Reportes automatizados, KPIs en tiempo real y alertas tempranas ante desviaciones.'),
   ('machine-learning','Machine Learning aplicado','Machine Learning aplicado','Predicción de demanda, churn, scoring de crédito, mantenimiento predictivo y pricing dinámico.'),
   ('mlops','MLOps &amp; automatización','MLOps y automatización','Pipelines de datos, modelos en producción y monitoreo continuo de desempeño.'),
   ('data-strategy','Data Strategy &amp; Governance','Data Strategy y Governance','Auditoría de datos, arquitectura de información y cumplimiento normativo.')]
# ---------- 1. páginas de servicio
base=rd('servicios/servicios.html')
head=re.search(r'<head>.*?</head>',base,re.S).group(0)
hdr=re.search(r'<body>\s*(<a href="#contenido">.*?</header>)',base,re.S).group(1).replace(' aria-current="page"','')
ftr=re.search(r'<footer>.*?</footer>',base,re.S).group(0)
for slug,name,plain,desc in S:
    h=re.sub(r'<title>.*?</title>',f'<title>{name} | DataForge</title>',head,flags=re.S)
    h=re.sub(r'<meta name="description" content="[^"]*">',f'<meta name="description" content="{plain}: página en construcción. {desc}">',h)
    page=f'''<!DOCTYPE html>
<html lang="es">
  {h}
  <body>
    {hdr}
    <main id="contenido">
      <!-- {plain} -->
      <section id="servicio" aria-labelledby="servicio-title">
        <header>
          <p>Servicios</p>
          <h1 id="servicio-title">{name}</h1>
          <p>{desc}</p>
        </header>
        <p><img src="../assets/Header/logo.webp" alt="DataForge" width="270" height="71"></p>
        <h2>Página en construcción</h2>
        <p>Estamos preparando el detalle de este servicio. Mientras tanto, puedes conocer los demás servicios o escribirnos para agendar tu diagnóstico gratuito.</p>
        <p><picture><source media="(min-width: 850px)" type="image/webp" srcset="../assets/Home/fondo.webp"> <source media="(max-width: 849px)" type="image/webp" srcset="../assets/Home/fondo-400.webp"> <img src="../assets/Home/fondo.png" alt="Ilustración de un panel de datos conectado a una red de nodos" width="400" height="348" loading="lazy" decoding="async"></picture></p>
        <p><a href="servicios.html#servicios">Volver a servicios</a> <a href="../contacto.html#contacto">Contáctanos</a></p>
      </section>
    </main>
    {ftr}
  </body>
</html>
'''
    wr(f'servicios/{slug}.html',page)
# ---------- 2. enlaces: tarjetas, pie de página y mapa del sitio
slug_of={n:s for s,n,_,_ in S}
for f in glob.glob(R+'*.html')+glob.glob(R+'*/*.html'):
    p=os.path.relpath(f,R); s=rd(p)
    s=re.sub(r'href="([^"]*?)servicios\.html#servicios">(Dashboards &amp; BI|Analítica descriptiva|Machine Learning|MLOps|Data Strategy)</a>',
        lambda m:f'href="{m.group(1)}{ {"Dashboards &amp; BI":"dashboards-bi","Analítica descriptiva":"analitica-descriptiva","Machine Learning":"machine-learning","MLOps":"mlops","Data Strategy":"data-strategy"}[m.group(2)] }.html">{m.group(2)}</a>',s)
    wr(p,s)
s=rd('servicios/servicios.html')
for slug,name,plain,desc in S:
    a=f'<a href="../contacto.html#contacto">Ver detalle de {plain}</a>'; assert a in s,plain
    s=s.replace(a,f'<a href="{slug}.html">Ver detalle de {plain}</a>')
wr('servicios/servicios.html',s)
m=rd('mapa_sitio.html'); old=re.search(r'<li><a href="servicios/servicios.html#servicios">Dashboards &amp; BI, Analítica.*?</li>',m).group(0)
m=m.replace(old,'\n'.join(f'<li><a href="servicios/{sl}.html">{n}</a></li>' for sl,n,_,_ in S)); wr('mapa_sitio.html',m)
# ---------- 3. casos de éxito
s=rd('casos_exito/casos_exito.html'); soup=BeautifulSoup(s,'html.parser'); keys=['retail','salud','logistica']
for art,k in zip(soup.find_all('article'),keys):
    ps=art.find_all('p'); tag=ps[0].get_text(strip=True); sector=' · '.join(x.strip().capitalize() for x in tag.split('·'))
    title=art.find('h2').get_text(strip=True); mets=[(p.find('strong').get_text(),p.find('span').get_text()) for p in ps[1:3]]
    quote=art.find('blockquote').get_text(strip=True); who=ps[3]; nm=who.find('strong').get_text(); rl=who.find('span').get_text()
    new=BeautifulSoup(f'''<article aria-labelledby="caso-{k}"><h2 id="caso-{k}">{sector}</h2><h3>{title}</h3><p>Resultados obtenidos:</p><ul>{"".join(f"<li><strong>{a}</strong> {b}</li>" for a,b in mets)}</ul><figure><blockquote><p>{quote}</p></blockquote><figcaption><strong>{nm}</strong>, {rl}</figcaption></figure></article>''','html.parser')
    art.replace_with(new)
out=str(soup)
# volver a sangrar de forma legible
out=re.sub(r'(<article[^>]*>)',r'\n        \1',out); out=re.sub(r'(<(?:h2|h3|ul|p|figure)[ >])',r'\n          \1',out) if False else out
wr('casos_exito/casos_exito.html',out)
# ---------- 4. blog: etiqueta de fecha y 4.º artículo
b=rd('blog/blog.html')
b=re.sub(r'<time datetime="([\d-]+)">([^<]+)</time>',r'<p>Publicado el <time datetime="\1">\2</time></p>',b)
art4='''<article>
          <img src="../assets/Blog/card4.webp" alt width="360" height="193" loading="lazy" decoding="async">
          <h2>Guía: checklist para conectar tus fuentes de datos</h2>
          <p>Una lista paso a paso para revisar tus sistemas (ERP, CRM y hojas de cálculo) antes de armar tu primer dashboard.</p>
          <p>Publicado el <time datetime="2026-02-18">18 de febrero de 2026</time></p>
        </article>
      </section>'''
assert '</article>\n      </section>' in b
b=b.replace('</article>\n      </section>','</article>\n        '+art4,1); wr('blog/blog.html',b)
W,H=1080,580; im=Image.new('RGB',(W,H),(12,32,96)); d=ImageDraw.Draw(im)
for y in range(H): d.line([(0,y),(W,y)],fill=(12+int(14*y/H),32+int(30*y/H),96+int(40*y/H)))
d.rounded_rectangle([140,70,700,510],28,fill=(255,255,255))
for i in range(4):
    y=130+i*95; d.rounded_rectangle([190,y,238,y+48],10,fill=(255,157,24)); d.line([(202,y+25),(212,y+36),(228,y+14)],fill=(255,255,255),width=7)
    d.rounded_rectangle([270,y+8,270+[330,270,300,220][i],y+22],7,fill=(214,222,232)); d.rounded_rectangle([270,y+30,270+[220,200,180,260][i]-60,y+40],5,fill=(232,237,243))
pts=[(800,140),(930,260),(820,380),(960,450)]
for a,c in zip(pts,pts[1:]): d.line([a,c],fill=(0,188,212),width=8)
for x,y in pts: d.ellipse([x-26,y-26,x+26,y+26],fill=(255,157,24),outline=(255,255,255),width=5)
im.resize((540,290),Image.LANCZOS).save(R+'assets/Blog/card4.webp','WEBP',quality=82,method=6)
print('listo')
