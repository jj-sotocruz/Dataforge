import re,os,glob,shutil
from bs4 import BeautifulSoup,NavigableString,Comment
SRC='/mnt/user-data/outputs/dataforge/'; DST='/mnt/user-data/outputs/dataforge_html/'
files=[f for f in glob.glob(SRC+'*/*.html')]
# destinos de enlaces/ids usados en el sitio
refs=set()
for f in files:
    s=open(f,encoding='utf8').read()
    refs|=set(re.findall(r'href="[^"]*#([\w-]+)"',s)); refs|=set(re.findall(r'href="#([\w-]+)"',s))
    for a in re.findall(r'aria-labelledby="([^"]+)"',s): refs|=set(a.split())
    refs|=set(re.findall(r'\bfor="([\w-]+)"',s))
PHR={'a','abbr','b','br','cite','code','em','i','img','input','label','mark','picture','q','select','small','span','strong','sub','sup','textarea','time','u','video','source','track','button','option'}
BLOCK_KEEP={'html','head','body','header','nav','main','section','article','aside','footer','form','fieldset','legend','ul','ol','li','table','caption','thead','tbody','tfoot','tr','figure','figcaption','blockquote','p','h1','h2','h3','h4','select','video','picture','textarea'}
VOID={'meta','link','img','input','br','source','track','hr'}
def cls(t): return ' '.join(t.get('class',[]))
def phrasing_only(t): return all(isinstance(c,NavigableString) or c.name in PHR for c in t.children)
def process(path):
    soup=BeautifulSoup(open(path,encoding='utf8').read(),'html.parser')
    for t in soup(['style','script','svg']): t.decompose()
    for t in soup.find_all('meta',attrs={'name':'theme-color'}): t.decompose()
    for t in soup.select('.header-actions,.dots,.avatar,.step-number,.form-status,.posts-next,.hero-visual svg'): t.decompose()
    for t in soup.find_all('input',attrs={'type':'radio','name':'cases'}): t.decompose()
    # logo
    for a in soup.select('a.logo'):
        a.attrs.pop('aria-label',None); a.img['alt']='DataForge, ir al inicio'
    # imágenes decorativas del hero / portal: texto alternativo descriptivo
    for img in soup.find_all('img',src=re.compile(r'Home/fondo')): img['alt']='Ilustración de un panel de datos conectado a una red de nodos'
    # botones de tarjeta -> enlaces a contacto
    for b in soup.select('button.card-link'):
        a=soup.new_tag('a',href='../home/contacto.html#contacto'); a.string=b.get('aria-label') or b.get_text(strip=True); p=soup.new_tag('p'); p.append(a); b.replace_with(p)
    for a in soup.select('a.forgot'): a['href']='contacto.html#contacto'
    # nav -> lista
    for nav in soup.find_all('nav',attrs={'aria-label':'Principal'}):
        links=nav.find_all('a'); ul=soup.new_tag('ul')
        for a in links:
            li=soup.new_tag('li'); li.append(a.extract()); ul.append(li)
        nav.clear(); nav.append(ul)
    # pie de página
    for p in soup.select('p.footer-title'): p.name='h2'; p.string=p.get_text().capitalize()
    for sp in soup.select('.footer-bottom > span'): sp.name='p'
    # radios del formulario -> fieldset/legend
    for lab in soup.select('span#interes-label'):
        fld=lab.parent; leg=soup.new_tag('legend'); leg.string=lab.get_text(strip=True); ch=fld.select_one('.choices')
        fs=soup.new_tag('fieldset'); fs.append(leg)
        for l in ch.find_all('label',recursive=False):
            p=soup.new_tag('p'); p.append(l.extract()); fs.append(p)
        fld.replace_with(fs)
    # clases semánticas -> elementos
    for t in soup.find_all(True):
        c=cls(t)
        if t.name=='div' and re.search(r'(number|-title|name)\b',c) and 'section' not in c: t.name='strong'
        elif t.name=='div' and re.search(r'(label|role|-text)\b',c): t.name='span'
        elif t.name=='p' and re.search(r'\b(case-tag|kicker|eyebrow|ey)\b',c): pass
        elif t.name=='span' and 'hint' in c: t.name='small'
    for sp in soup.select('.sr-only'): sp.decompose()
    for t in soup.select('.member-name'): t.name='h2'
    for t in soup.select('.step-title'): t.name='h3'
    # divs: solo fraseo -> p ; resto -> desenvolver (de adentro hacia afuera)
    for d in reversed(soup.find_all('div')):
        if not d.get_text(strip=True) and not d.find(['img','picture','video','input','select','textarea','table']): d.decompose(); continue
        if phrasing_only(d) and d.find_parent(['p']) is None:
            d.name='p'
            kids=[c for c in d.children if getattr(c,'name',None)]
            if kids and kids[0].name=='label' and len(kids)>1 and kids[1].name in('input','select','textarea'): kids[0].insert_after(soup.new_tag('br'))
            for k in kids:
                if k.name=='small': k.insert_before(soup.new_tag('br'))
        else: d.unwrap()
    for st in soup.find_all('strong'):
        n=st.next_sibling
        if getattr(n,'name',None)=='span': st.insert_after(NavigableString(' '))
    for s in soup.select('section > section'): s.unwrap()
    # botones fuera de formularios (sin JS no funcionan)
    for b in soup.find_all('button'):
        if b.find_parent('form') is None: b.decompose()
    for f in soup.find_all('form'): f['method']='post'
    # límites de fecha dependían de JS
    for t in soup.find_all(attrs={'type':'date'}): t.attrs.pop('min',None); t.attrs.pop('max',None)
    # niveles de encabezado sin saltos
    stack=[]
    for h in soup.find_all(re.compile(r'^h[1-6]$')):
        o=int(h.name[1])
        while stack and stack[-1][0]>=o: stack.pop()
        n=stack[-1][1]+1 if stack else o
        h.name=f'h{n}'; stack.append((o,n))
    # atributos de presentación / JS
    for t in soup.find_all(True):
        for a in list(t.attrs):
            if a in('class','style','role','tabindex','aria-hidden','aria-expanded','aria-controls') or a.startswith('data-'): del t.attrs[a]
        if t.get('id') and t['id'] not in refs: del t.attrs['id']
        if t.name=='img' and 'width' not in t.attrs: pass
    for t in soup.find_all(string=lambda s:isinstance(s,Comment) and 'Pendiente' in s): t.extract()
    return soup
def esc(s,a=False):
    s=s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    return s.replace('"','&quot;') if a else s
def attrs(t): return ''.join(f' {k}' if v=='' else f' {k}="{esc(v if isinstance(v,str) else " ".join(v),True)}"' for k,v in t.attrs.items())
def ser(t,ind=0):
    pad='  '*ind
    if isinstance(t,Comment): return [pad+f'<!--{t}-->']
    if t.name in VOID: return [pad+f'<{t.name}{attrs(t)}>']
    kids=[c for c in t.children if not(isinstance(c,NavigableString) and not isinstance(c,Comment) and not str(c).strip())]
    inline=t.name in('p','h1','h2','h3','h4','li','legend','caption','th','td','figcaption','blockquote','title','label','a','strong','span','em','time','small','option','button','textarea') or all((isinstance(c,NavigableString) and not isinstance(c,Comment)) or c.name in PHR|{'em','strong'} for c in kids)
    if inline and all((isinstance(c,NavigableString) and not isinstance(c,Comment)) or c.name in PHR for c in kids):
        return [pad+f'<{t.name}{attrs(t)}>'+inl(t)+f'</{t.name}>']
    out=[pad+f'<{t.name}{attrs(t)}>']; run=[]
    def flush():
        if run: out.append('  '*(ind+1)+''.join(inl_node(c) for c in run).strip()); run.clear()
    for c in kids:
        if isinstance(c,Comment): flush(); out.append('  '*(ind+1)+f'<!--{c}-->'); continue
        if isinstance(c,NavigableString) or (c.name in PHR and c.name not in('video','picture')): run.append(c)
        else: flush(); out+=ser(c,ind+1)
    flush(); out.append(pad+f'</{t.name}>'); return out
def inl_node(c):
    if isinstance(c,NavigableString): return esc(re.sub(r'\s+',' ',str(c)))
    if c.name in VOID: return f'<{c.name}{attrs(c)}>'
    return f'<{c.name}{attrs(c)}>'+inl(c)+f'</{c.name}>'
def inl(t): return re.sub(r'\s+',' ',''.join(inl_node(c) for c in t.children)).strip()
for f in files:
    soup=process(f); rel=os.path.relpath(f,SRC); os.makedirs(os.path.dirname(DST+rel),exist_ok=True)
    html=soup.find('html'); lines=['<!DOCTYPE html>']+ser(html)
    open(DST+rel,'w',encoding='utf8').write('\n'.join(lines)+'\n')
if os.path.exists(DST+'assets'): shutil.rmtree(DST+'assets')
shutil.copytree(SRC+'assets',DST+'assets')
print('ok',len(files))
